/* PersonAtMCC.cpp - Function definitions for parent class
 * Author:     <your name>
 * Module:     7
 * Project:    Lab, Part 1
 * Description:  Function definitions for parent class
 */

#include "PersonAtMCC.h"
#include <iostream>
using namespace std ;

/**** WRITE THE MISSING CONSTRUCTORS, USE MEMBER INITIALIZATION ****/

PersonAtMCC::PersonAtMCC()
{
    setId(0);
    setName("");
    setAddress("");
    setPhone("");
}
PersonAtMCC::PersonAtMCC(long theId, string theName)
{
    setId(theId);
    setName(theName);
    setAddress("");
    setPhone("");

}
PersonAtMCC::PersonAtMCC(long theId, string theName, string theAddress, string thePhone)
{
    setId(theId);
    setName(theName);
    setAddress(theAddress);
    setPhone(thePhone);

}

// getters and setters
long PersonAtMCC::getId() {
    return id ;
}

string PersonAtMCC::getName() {
    return name ;
}

string PersonAtMCC::getAddress() {
    return address ;
}

string PersonAtMCC::getPhone() {
    return phone ;
}

// Setters
void PersonAtMCC::setId(long new_id) {
    id = new_id ;
}

void PersonAtMCC::setName(string new_name) {
    name = new_name ;
}

void PersonAtMCC::setAddress(string new_address) {
    address = new_address ;
}

void PersonAtMCC::setPhone(string new_phone) {
    phone = new_phone ;
}

void PersonAtMCC::showInfo() {
    cout << "ID: " << getId() <<"  Name: "<<getName()<<"  Address:"<<getAddress()<<endl
    <<"Phone:"<<getPhone()<<"\n"<<endl;

    /**** COMPLETE THE OUTPUT ****/
}
