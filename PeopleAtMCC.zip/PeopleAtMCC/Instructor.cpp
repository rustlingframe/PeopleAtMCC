/* Instructor.cpp - Definition of functions for the Instructor subclass to PersonAtMCC
 * Author:     <your name>
 * Module:     7
 * Project:    Lab, Part 1
 */

#include "Instructor.h"
#include <iostream>
using namespace std ;

/**** WRITE THE MISSING CONSTRUCTOR, USE MEMBER INITIALIZATION ****/

Instructor::Instructor(long theId, string theName, string theAddress, string thePhone, string theDepartment, bool permanentStatus, double thePayRate, double theHours)
{
    setId(theId);
    setName(theName);
    setAddress(theAddress);
    setPhone(thePhone);
    department = theDepartment;
    is_permanent = permanentStatus;
    pay_rate = thePayRate;
    hours = theHours;
}

// Getters for this class only
string Instructor::getDepartment() {
    return department ;
}

bool Instructor::getIsPermanent() {
    return is_permanent ;
}

double Instructor::getPayRate() {
    return pay_rate ;
}

double Instructor::getHours() {
    return hours;
}

// Setters for this class only
void Instructor::setDepartment(string new_department) {
    department = new_department ;
}

void Instructor::setIsPermanent(bool new_is_permanent) {
    is_permanent = new_is_permanent ;
}

void Instructor::setPayRate(double new_pay_rate) {
    pay_rate = new_pay_rate ;
}

void Instructor::showInfo() {

    PersonAtMCC :: showInfo();
    cout<<"Department: "<<getDepartment()<<"  Permanent:"<<getIsPermanent()<<"  Pay-Rate:"<<getPayRate()<<"  Hours:"<<getHours()<<"\n"<<endl;

    /**** COMPLETE THE OUTPUT ****/
}
