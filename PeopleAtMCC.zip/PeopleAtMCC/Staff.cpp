/* Staff.cpp - Function definition file for Staff, child of PersonAtMCC
 * Author:     <your name>
 * Module:     7
 * Project:    Lab, Part 1
 */

#include "Staff.h"
#include <iostream>
using namespace std ;

/**** WRITE THE MISSING CONSTRUCTOR, USE MEMBER INITIALIZATION ****/

Staff::Staff(long theId, string theName, string theAddress, string thePhone, string theExtension, string theHireDate, double thePayRate)
{
    setId(theId);
    setName(theName);
    setAddress(theAddress);
    setPhone(thePhone);
    extension = theExtension;
    hire_date = theHireDate;
    pay_rate = thePayRate;

}

// Getters for this class only
string Staff::getExtension() {
    return extension ;
}

string Staff::getHireDate() {
    return hire_date ;
}

double Staff::getPayRate() {
    return pay_rate ;
}

// Setters for this class only
void Staff::setExtension(string new_extension) {
    extension = new_extension ;
}

void Staff::setHireDate(string new_hire_date) {
    hire_date = new_hire_date ;
}

void Staff::setPayRate(double new_pay_rate) {
    pay_rate = new_pay_rate ;
}

void Staff::showInfo() {

    PersonAtMCC :: showInfo();
    cout<<"Extension: "<<getExtension()<<"  Hire Date: "<<getHireDate()<<"Pay-Rate: "<<getPayRate()<<"\n"<<endl;

    /**** COMPLETE THE OUTPUT ****/
}

